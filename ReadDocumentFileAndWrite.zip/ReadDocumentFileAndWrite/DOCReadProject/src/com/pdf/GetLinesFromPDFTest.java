package com.pdf;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * This is an example on how to extract text line by line from pdf document
 */
public class GetLinesFromPDFTest extends PDFTextStripper {

	static List<String> lines = new ArrayList<String>();
	static List<String> paraGraphs = new ArrayList<String>();

	public GetLinesFromPDFTest() throws IOException {
	}

	/**
	 * @throws IOException
	 *             If there is an error parsing the document.
	 */
	public static void main(String[] args) throws IOException {
		PDDocument document = null;
		String fileName = "D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\KB000028905.pdf";
		try {
			document = PDDocument.load(new File(fileName));
			PDFTextStripper stripper = new GetLinesFromPDFTest();
			stripper.setSortByPosition(true);
			stripper.setStartPage(0);
			stripper.setEndPage(document.getNumberOfPages());

			Writer dummy = new OutputStreamWriter(new ByteArrayOutputStream());
			stripper.writeText(document, dummy);

			// print lines
			writeText(lines);
		} finally {
			if (document != null) {
				document.close();
			}
		}

	}

	public static void writeText(List<String> inputParagraph) {
		try {

			// List<String> paraGraphs21=new ArrayList<String>();
			File file = new File(
					"D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\test.pdf");
			FileOutputStream pdfFileout = new FileOutputStream(file);
			Document doc = new Document();
			PdfWriter.getInstance(doc, pdfFileout);
			
			/*doc.addAuthor("QuicklyJava.com");
			doc.addTitle("This is title");*/
			doc.open();

			Paragraph para1 = new Paragraph();
			for (String paraGraphs : inputParagraph) {					
					if(paraGraphs.contains("FSCYAN_YANPDOWN_SCHEMA")){
						para1.add(paraGraphs);//+"\n");
						//System.out.println("\n");
						//System.out.println("Paragraph::: "+paraGraphs);
					}
					
			}
			doc.add(para1);
			doc.close();
			pdfFileout.close();

			// System.out.println("Success!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Override the default functionality of PDFTextStripper.writeString()
	 */
	@Override
	protected void writeString(String str, List<TextPosition> textPositions)
			throws IOException {
		lines.add(str);
		// you may process the line here itself, as and when it is obtained
	}
}