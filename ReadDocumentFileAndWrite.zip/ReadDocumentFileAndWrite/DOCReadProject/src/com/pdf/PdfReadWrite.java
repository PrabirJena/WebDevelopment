package com.pdf;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

public class PdfReadWrite {

	public static void main(String[] args) {
		String pageContent = "";
		List<String> aTextList=new ArrayList<String>();
		try {
			// Create PdfReader instance.
			PdfReader pdfReader = new PdfReader(
					"D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\KB000028905.pdf");
			
			

			// Get the number of pages in pdf.
			int pages = pdfReader.getNumberOfPages();
			// Iterate the pdf through pages.
			for (int i = 1; i <= pages; i++) {
				// Extract the page content using PdfTextExtractor.
				pageContent = PdfTextExtractor.getTextFromPage(pdfReader, i);
				
				aTextList.add(pageContent);
				// Print the page content on console.
				/*System.out.println("Content on Page " + i + ": " + pageContent);*/
			}	
			writeTextContent(aTextList);
			// Close the PdfReader.
			pdfReader.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void writeTextContent(List<String> pageContent) {
		try {
			/*// Create Document instance.
			Document document = new Document();
			
			// Create OutputStream instance.
			OutputStream outputStream = new FileOutputStream(new File(
					"D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\WritePDF.pdf"));*/
            File file = new File("D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\testpdf.pdf");
            FileOutputStream pdfFileout = new FileOutputStream(file);
            Document document = new Document();
           // PdfWriter.getInstance(document, pdfFileout);

			// Create PDFWriter instance.
			PdfWriter.getInstance(document, pdfFileout);
			// Open the document.
			document.open();

			// Add content to the document.
		
			
		for(String text:pageContent){
			Paragraph paragraph=new Paragraph();
			
			
				//if(text.contains("FSCYAN_YANPDOWN_SCHEMA")){
					String[] stringarr=text.split("\n");
					//System.out.println(stringarr[0]);
					for(String str:stringarr){
						if(str.contains("FSCYAN_YANPDOWN_SCHEMA")){
							paragraph.add(str);
							System.out.println(str);
						}
					//}
					/*if(text.startsWith("select")){
					
						System.out.println(stringarr[0]);
					}*/
					//System.out.println("test info : "+text);
				}
				//paragraph.add(text);
				document.add(paragraph);
				//System.out.println("test info : "+pageContent.get(0));
				//}
			}
			
			// Close document and outputStream.
			document.close();
			pdfFileout.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
