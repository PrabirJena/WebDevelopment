package com.tst;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/**
 * This is an example on how to extract text line by line from pdf document
 */
public class GetLinesFromPDF extends PDFTextStripper {
	
	static List<String> lines = new ArrayList<String>();

	public GetLinesFromPDF() throws IOException {
	}

	/**
	 * @throws IOException If there is an error parsing the document.
	 */
	public static void main( String[] args ) throws IOException	{
		PDDocument document = null;
		String fileName = "D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\apache.pdf";
		try {
			document = PDDocument.load( new File(fileName) );
			PDFTextStripper stripper = new GetLinesFromPDF();
            stripper.setSortByPosition( true );
            stripper.setStartPage( 0 );
            stripper.setEndPage( document.getNumberOfPages() );

            Writer dummy = new OutputStreamWriter(new ByteArrayOutputStream());
            stripper.writeText(document, dummy);
            
            // print lines
            for(String line:lines){
            	System.out.println(line);            	
            }
		}
		finally {
			if( document != null ) {
				document.close();
			}
		}
		
		
		
        File filename1 = new File("D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\sample.txt");
        //String message = "This is a sample PDF document created using PDFBox.";

        PDDocument doc = new PDDocument();
        try {
            PDPage page = new PDPage();
            doc.addPage(page);
            PDFont font = PDType1Font.HELVETICA_BOLD;                  
            PDPageContentStream contents = new PDPageContentStream(doc, page);
           
        for(String line1:lines){
        	System.out.println(line1);    	
        	contents.beginText();
            contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
            contents.newLineAtOffset(50, 700);
            contents.showText(line1);
            contents.endText();            
            contents.close();            
            doc.save(filename1);
            
        }
        
        
       }finally {
           doc.close();
       }
    
	}

	/**
	 * Override the default functionality of PDFTextStripper.writeString()
	 */
	
	@Override
	protected void writeString(String str, List<TextPosition> textPositions) throws IOException {
		lines.add(str);
		// you may process the line here itself, as and when it is obtained
	}
}