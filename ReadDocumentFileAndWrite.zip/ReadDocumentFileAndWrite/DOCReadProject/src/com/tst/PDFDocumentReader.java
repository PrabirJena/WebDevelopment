package com.tst;

import java.io.IOException;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;


public class PDFDocumentReader {

	public static void main(String[] args) {
        pdfDocScanner();
 
    }

	public static String pdfDocScanner() {
		String page = "";
		try {
             
            PdfReader reader = new PdfReader("D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\SQLQueries.pdf");
            System.out.println("This PDF has "+reader.getNumberOfPages()+" pages.");
             page = PdfTextExtractor.getTextFromPage(reader, 1);
            System.out.println("Page Content:\n\n"+page+"\n\n"); 
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		return page;
	}

}
