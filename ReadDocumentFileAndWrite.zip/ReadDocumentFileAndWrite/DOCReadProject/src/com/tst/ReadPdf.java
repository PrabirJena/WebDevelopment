package com.tst;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReadPdf {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws Exception {

		System.out.println("-------- Oracle JDBC Connection Testing ------");
		// readDocxFile("D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\SQLQueries.docx");
		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@192.168.7.39:1521:ORCL", "ENT_2181019",
					"ENT_2181019");
			// step3 create the statement object
			Statement stmt = connection.createStatement();
			String pString = readPdfFile();

			// step4 execute query
			// ResultSet rs=stmt.executeQuery("select * from account");
			if (isValid(pString)) {
				ResultSet rs = stmt.executeQuery(pString);
				while (rs.next()) {
					System.out.println(rs.getString(1) + "  " + rs.getInt(2));
					// System.out.println(rs.getInt(1)+"  "+rs.getDate(2));
				}
			} else {
				throw new Exception(
						"The sql query is invalid as where clause is not found");
			}
			// step5 close the connection object
			connection.close();

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}

		if (connection != null) {
			System.out
					.println("Connection Successful and able to Fetch the ResultSet");
		} else {
			System.out.println("Failed to make connection!");
		}
	}

	public static boolean isValid(String str) {
		// using pattern with flags
		Pattern pattern = Pattern.compile("where");
		Matcher matcher = pattern.matcher(str);
		// using Matcher find(), group(), start() and end() methods
		while (matcher.find()) {
			System.out.println(matcher.group(0));
			return true;
		}
		return false;
	}

	public static String readPdfFile() throws InvalidPasswordException,
			IOException {
		PDDocument document = PDDocument.load(new File(
				"D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\SQLQueries.pdf"));
		String pString = "";
		try {

			document.getClass();

			if (!document.isEncrypted()) {

				PDFTextStripperByArea stripper = new PDFTextStripperByArea();
				stripper.setSortByPosition(true);

				PDFTextStripper tStripper = new PDFTextStripper();

				String pdfFileInText = tStripper.getText(document);
				// System.out.println("Text:" + pdfFileInText);

				// split by whitespace
				String lines[] = pdfFileInText.split("\\r?\\n");
				for (int i = 0; i < lines.length; i++) {
					pString = lines[i];
					System.out.println("Paragraph String : " + pString);
				}

				/*
				 * for (String line : lines) { System.out.println(line); }
				 */

			}

		} catch (Exception e) {

		}
		return pString;
	}
}