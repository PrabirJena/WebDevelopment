package com.tst;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
public class TestDoc2 {
	 static String pString = "";
	    public static String readDocxFile() {
	            try {
	                File file = new File("D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\SQLQueries.docx");
	                FileInputStream fis = new FileInputStream(file.getAbsolutePath());

	                XWPFDocument document = new XWPFDocument(fis);

	                List<XWPFParagraph> paragraphs = document.getParagraphs();


	                for (XWPFParagraph para : paragraphs) {
	                	pString=para.getText();
	                    System.out.println(para.getText());
	                }
	                fis.close();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
				return pString;
	        }
	    
	    @SuppressWarnings("unused")
		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			
			System.out.println("-------- Oracle JDBC Connection Testing ------");
			//readDocxFile("D:\\WorkSpaceSVNCode\\DOCReadProject\\src\\SQLQueries.docx");
	        try {

	            Class.forName("oracle.jdbc.driver.OracleDriver");

	        } catch (ClassNotFoundException e) {

	            System.out.println("Where is your Oracle JDBC Driver?");
	            e.printStackTrace();
	            return;

	        }

	        System.out.println("Oracle JDBC Driver Registered!");

	        Connection connection = null;

	        try {

	            connection = DriverManager.getConnection(
	                    "jdbc:oracle:thin:@192.168.7.39:1521:ORCL", "ENT_2181019", "ENT_2181019");
	          //step3 create the statement object  
	            Statement stmt=connection.createStatement();  
	            String pString=readDocxFile();
	              
	            //step4 execute query  
	            //ResultSet rs=stmt.executeQuery("select * from account");  
	            ResultSet rs=stmt.executeQuery(pString);
	            while(rs.next()) {
	            System.out.println(rs.getString(1)+"  "+rs.getInt(2));
	            //System.out.println(rs.getInt(1)+"  "+rs.getDate(2));
	            }
	              
	            //step5 close the connection object  
	            //connection.close();  

	        } catch (SQLException e) {

	            System.out.println("Connection Failed! Check output console");
	            e.printStackTrace();
	            return;

	        }

	        if (connection != null) {
	            System.out.println("You made it, take control your database now!");
	        } else {
	            System.out.println("Failed to make connection!");
	        }
	    }
			

}
