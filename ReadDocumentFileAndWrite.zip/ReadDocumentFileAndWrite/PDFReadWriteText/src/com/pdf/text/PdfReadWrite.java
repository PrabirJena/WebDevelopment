package com.pdf.text;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.parser.PdfTextExtractor;

public class PdfReadWrite {

	public static void main(String[] args) {
		String pageContent = "";
		List<String> aTextList = new ArrayList<String>();
		try {
			// Create PdfReader instance.
			PdfReader pdfReader = new PdfReader(
					"D:\\WorkSpaceSVNCode\\PDFReadWriteText\\src\\KB000028905.pdf");

			// Get the number of pages in pdf.
			int pages = pdfReader.getNumberOfPages();
			// Iterate the pdf through pages.
			for (int i = 1; i <= pages; i++) {
				// Extract the page content using PdfTextExtractor.
				pageContent = new PdfTextExtractor(pdfReader).getTextFromPage(i);
				aTextList.add(pageContent);
			}
			writeTextContent(aTextList);
			// Close the PdfReader.
			pdfReader.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void writeTextContent(List<String> pageContent) {
		try {

			File file = new File(
					"D:\\WorkSpaceSVNCode\\PDFReadWriteText\\src\\testpdf.pdf");
			FileOutputStream pdfFileout = new FileOutputStream(file);
			Document document = new Document();

			// Create PDFWriter instance.
			PdfWriter.getInstance(document, pdfFileout);
			// Open the document.
			document.open();

			// Add content to the document.

			for (String text : pageContent) {
				Paragraph paragraph = new Paragraph();

				String[] stringarr = text.split("\n");
				for (String str : stringarr) {
					if (str.contains("FSCYAN_YANPDOWN_SCHEMA")) {
						paragraph.add(str+"\n");
						System.out.println(str);
					}
				}
				document.add(paragraph);
			}

			// Close document and outputStream.
			document.close();
			pdfFileout.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
